#include <iostream>
#include <vector>
#include "structs.h"
#include "io.h"
#include "MironSolution.h"
using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    f();
    return 0;
}
