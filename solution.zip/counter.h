//
// Created by tchu on 3/1/18.
//

#ifndef HASHCODE_COUNTER_H
#define HASHCODE_COUNTER_H

#include "state.h"

int countPoints(parameters &t, std::list<ride> &ridesl);

#endif //HASHCODE_COUNTER_H
