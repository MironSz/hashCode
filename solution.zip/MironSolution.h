//
// Created by Kamil Mykitiuk on 01/03/2018.
//

#ifndef HASHCODE_MIRONSOLUTION_H
#define HASHCODE_MIRONSOLUTION_H
void f();
#endif //HASHCODE_MIRONSOLUTION_H
